import Form from "./components/Form";
import Form2 from "./components/Form2";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1>Event and Event Bubbling </h1>
      <hr />
      <Form />
      <Form2 />
    </div>
  );
}
