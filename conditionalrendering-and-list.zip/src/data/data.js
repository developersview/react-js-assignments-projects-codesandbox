let items = ["India", "France", "Israel", "Russia", "Canada"];

export default items;
